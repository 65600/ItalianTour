package it.unica.ium.italiantour;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

public class MainMapActivity extends FragmentActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_map);

    }

}
